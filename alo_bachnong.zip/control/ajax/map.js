$(document).ready(function(){
	alert('ákhasfhoas');
});